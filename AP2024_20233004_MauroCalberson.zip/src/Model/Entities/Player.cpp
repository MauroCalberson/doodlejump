
#include "Player.h"

void Player::addObserver(std::shared_ptr<Observer> o) {
    this->observer = o;
}
