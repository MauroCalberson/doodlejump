//
// Created by mauro on 31/12/2024.
//

#ifndef DOODLEJUMP_BGTILE_H
#define DOODLEJUMP_BGTILE_H
#include "Entitymodel.h"

class BGTile : public Entitymodel{
    double lefttop;
public:
    BGTile() = default;
};

#endif // DOODLEJUMP_BGTILE_H
