

#ifndef DOODLEJUMP_ENTITYMODEL_H
#define DOODLEJUMP_ENTITYMODEL_H

#include "../../Helper/Random.h"
#include "Subject.h"
class Entitymodel : public Subject {
protected:
    float x;
    float y;
    std::shared_ptr<Observer> observer;

public:
    //Entitymodel() = default;
    float getX() override { return x; }
    float getY() override { return y; }
    void setX(float x);
    void setY(float y);
    void notifyObservers() override;
    virtual void addObserver(std::shared_ptr<Observer> o);
};


#endif // DOODLEJUMP_ENTITYMODEL_H
