//
// Created by mauro on 31/12/2024.
//

#include "BGTile.h"
