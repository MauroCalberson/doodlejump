
#ifndef DOODLEJUMP_SUBJECT_H
#define DOODLEJUMP_SUBJECT_H
#include <memory>
class Observer;
class Subject {
public:
    virtual float getX() = 0;
    virtual float getY() = 0;
    virtual void notifyObservers() = 0;
    Subject() = default;
    ~Subject() = default;
};

#endif // DOODLEJUMP_SUBJECT_H
