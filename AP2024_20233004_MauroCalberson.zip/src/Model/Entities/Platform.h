

#ifndef DOODLEJUMP_PLATFORM_H
#define DOODLEJUMP_PLATFORM_H
#include "../Enums.h"
#include "Entitymodel.h"
class Platform : public Entitymodel{
public:
    bool jumpedon;
    PlatformType type;
    void setType(PlatformType& t);
    //Platform() = default;
};
class DynamicPlatform : public Platform {
    VertDirection vertDirection = DOWN;
    HorDirection horDirection = RIGHT;
public:
    //DynamicPlatform() = default;
};


#endif //DOODLEJUMP_PLATFORM_H
