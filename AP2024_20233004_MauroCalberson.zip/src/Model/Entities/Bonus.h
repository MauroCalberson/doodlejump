

#ifndef DOODLEJUMP_BONUS_H
#define DOODLEJUMP_BONUS_H
#include "Entitymodel.h"

class Bonus : public Entitymodel{
public:
    //Bonus() = default;
};

#endif // DOODLEJUMP_BONUS_H
