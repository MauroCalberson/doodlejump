

#include "Entitymodel.h"
#include "../Observer.h"

void Entitymodel::setX(float x) {
    this->x = x;
}
void Entitymodel::setY(float y) {
    this->y = y;
}
void Entitymodel::notifyObservers() {
    this->observer->update();
}
void Entitymodel::addObserver(std::shared_ptr<Observer> o) {
    this->observer = o;
}