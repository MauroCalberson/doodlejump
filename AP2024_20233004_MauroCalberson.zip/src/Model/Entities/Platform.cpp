

#include "Platform.h"

void Platform::setType(PlatformType& t) {
    type = t;
}