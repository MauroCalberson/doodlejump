
#include "../Game.h"
#include "World.h"
#include <iostream>
World::World() {
    setup();
}

void World::setup() {
    std::cout << Game::getInstance()->getPlayerView() << std::endl;
    std::shared_ptr<AbstractFactory> factory = std::make_shared<ConcreteFactory>();
    std::cout << Game::getInstance()->getPlayerView() << std::endl;

    player = factory->createPlayer();
    std::cout << Game::getInstance()->getPlayerView() << std::endl;

    update();
    std::cout << Game::getInstance()->getPlayerView() << std::endl;

    player->notifyObservers();
    std::cout << Game::getInstance()->getPlayerView() << std::endl;

}
void World::update() {

}
