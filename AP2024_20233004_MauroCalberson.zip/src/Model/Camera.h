

#ifndef DOODLEJUMP_CAMERA_H
#define DOODLEJUMP_CAMERA_H

class Camera {
    float x;
    float y;
};

#endif // DOODLEJUMP_CAMERA_H
