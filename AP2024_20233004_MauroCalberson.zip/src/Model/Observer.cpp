
#include "../View/EntitytView.h"
#include "Entities/Subject.h"
#include "Observer.h"
void Observer::setView(std::shared_ptr<EntityView> v) {
    this->view = v;
}
void Observer::setSubject(std::shared_ptr<Subject> s) {
    this->subject = s;
}
void Observer::update() {
    view->setX(subject->getX());
    view->setY(subject->getY());
}