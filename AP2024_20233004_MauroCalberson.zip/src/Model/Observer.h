

#ifndef DOODLEJUMP_OBSERVER_H
#define DOODLEJUMP_OBSERVER_H
#include <memory>
#include <vector>
/*#include "../View/EntitytView.h"
#include "Entities/Subject.h"*/
class Subject;
class EntityView;
class Observer {
public:
    Observer() = default;
    void update();
    virtual void setView(std::shared_ptr<EntityView> v);
    virtual void setSubject(std::shared_ptr<Subject> s);
    virtual void setX(float x) = 0;
    virtual void setY(float x) = 0;

private:
    std::shared_ptr<Subject> subject;
    std::shared_ptr<EntityView> view;
};

#endif // DOODLEJUMP_OBSERVER_H
