// Game.h
#ifndef DOODLEJUMP_GAME_H
#define DOODLEJUMP_GAME_H

#include <SFML/Graphics.hpp>
#include "View/EntitytView.h"
#include "View/PlatformView.h"
#include "View/PlayerView.h"
#include "Model/World.h"
#include <iostream>
class World;
class Game {
public:
    Game();
    void run();
    void addPlayerView(std::shared_ptr<PlayerView> v);
    void addPlatformView(std::shared_ptr<PlatformView> v);
    static std::unique_ptr<Game>& getInstance() {
        if (!instance) {
            instance = std::make_unique<Game>();  // Create the instance if it doesn't exist
        }
        return instance;
    }
    std::shared_ptr<PlayerView> getPlayerView();
private:
    static std::unique_ptr<Game> instance;
    void processEvents();
    void update();
    void render();
    void displayentities(sf::RenderWindow& window);
    std::vector<std::shared_ptr<PlatformView>> platforms;
    std::shared_ptr<PlayerView> player;
    sf::RenderWindow window;
    std::unique_ptr<World> world;
};

#endif // DOODLEJUMP_GAME_H