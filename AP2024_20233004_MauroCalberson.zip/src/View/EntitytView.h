

#ifndef DOODLEJUMP_ENTITYTVIEW_H
#define DOODLEJUMP_ENTITYTVIEW_H
#include "../Model/Observer.h"
#include <Graphics.hpp>
class EntityView : public Observer {
public:
    void setX(float x) override;
    void setY(float y)override;
    sf::Sprite getSprite();
protected:
    float x;
    float y;
    sf::Texture texture;
    sf::Sprite sprite;
};

#endif // DOODLEJUMP_ENTITYTVIEW_H
