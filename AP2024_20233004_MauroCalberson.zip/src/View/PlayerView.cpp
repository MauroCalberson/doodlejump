
#include <iostream>
#include "PlayerView.h"
PlayerView::PlayerView() {
    this->setTexture();
}
void PlayerView::setTexture() {
    sf::Texture texture1;
    texture1.loadFromFile("textures/doodleplayer.png");
    this->texture = texture1;
    sprite.setTexture(texture);
    sprite.setPosition(x,y);
    std::cout << x << std::endl;
}