
#include "EntitytView.h"
#include "PlayerView.h"
#include "PlatformView.h"
#include "ConcreteFactory.h"
#include "../Controller/PlatformController.h"
#include "../Controller/PlayerController.h"
std::shared_ptr<Platform> ConcreteFactory::createPlatform(PlatformType platform) {
    PlatformController platcontrol;
    Platform p;
    p.setType(platform);
    PlatformView pview;
    pview.setType(platform);
    return std::make_shared<Platform> (p);
}
std::shared_ptr<Player> ConcreteFactory::createPlayer() {
    std::shared_ptr<Observer> o = std::make_shared<EntityView>();
    PlayerController player;
    std::shared_ptr<Player> p = std::make_shared<Player>();
    p->setX(500.0);
    p->setY(200.0);
    std::shared_ptr<PlayerView> pv = std::make_shared<PlayerView>();
    o->setView(pv);
    p->addObserver(o);
    o->setSubject(p);
    std::shared_ptr<PlayerController> pl = std::make_shared<PlayerController>(player);
    Game::getInstance()->addPlayerView(pv);
    std::cout << Game::getInstance()->getPlayerView() << std::endl;
    return p;
}
std::shared_ptr<Bonus> ConcreteFactory::createBonus() {
    int s;
    s=s+1;
    return nullptr;
}
std::shared_ptr<BGTile> ConcreteFactory::createBGTile() {
    int s;
    s=s+1;
    return nullptr;
}