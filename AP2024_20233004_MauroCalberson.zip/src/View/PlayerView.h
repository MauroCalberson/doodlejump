
#ifndef DOODLEJUMP_PLAYERVIEW_H
#define DOODLEJUMP_PLAYERVIEW_H
#include <SFML/Graphics.hpp>
#include "EntitytView.h"
class PlayerView : public EntityView {
public:
    PlayerView();
    void setTexture();
};

#endif // DOODLEJUMP_PLAYERVIEW_H
