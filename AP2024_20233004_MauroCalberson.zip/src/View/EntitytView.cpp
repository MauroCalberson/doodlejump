
#include <iostream>
#include "EntitytView.h"
void EntityView::setX(float X) {
    this->x = X;
}
void EntityView::setY(float Y) {
    this->y = Y;
    sprite.setPosition(x,y);
}
sf::Sprite EntityView::getSprite() {
    return sprite;
}