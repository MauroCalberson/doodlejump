

#include "PlatformView.h"

void PlatformView::setTexture() {
    if(type == PlatformType::Green) {
        texture.loadFromFile("../textures/platform1.png");
        sprite.setTexture(texture);
    }
    else if(type == PlatformType::Blue) {
        texture.loadFromFile("../textures/platform2.png");
        sprite.setTexture(texture);
    }
    else if(type == PlatformType::Yellow) {
        texture.loadFromFile("../textures/platform3.png");
        sprite.setTexture(texture);
    }
    else if(type == PlatformType::White) {
        texture.loadFromFile("../textures/platform4.png");
        sprite.setTexture(texture);
    }
}
PlatformType PlatformView::getType() {
    return type;
}
void PlatformView::setType(PlatformType& ptype) {
    type = ptype;
}