

#ifndef DOODLEJUMP_PLATFORMVIEW_H
#define DOODLEJUMP_PLATFORMVIEW_H
#include "EntitytView.h"
#include "../Model/Enums.h"
class PlatformView : public EntityView{
private:
    PlatformType type;
public:
    PlatformView() = default;
    ~PlatformView() = default;
    void setTexture();
    PlatformType getType();
    void setType(PlatformType& ptype);
};

#endif // DOODLEJUMP_PLATFORMVIEW_H
