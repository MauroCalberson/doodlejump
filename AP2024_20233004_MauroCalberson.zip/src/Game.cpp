

#include "Game.h"
#include <iostream>
Game::Game() : window(sf::VideoMode(600, 800), "Doodle Jump"), world() {
}
std::unique_ptr<Game> Game::instance = nullptr;

void Game::run() {
    world = std::make_unique<World>();
    std::cout << Game::getInstance()->getPlayerView() << std::endl;

    world->update();
    std::cout << Game::getInstance()->getPlayerView() << std::endl;

    while (window.isOpen()) {
        processEvents();
        update();
        render();
    }
}

void Game::processEvents() {
    sf::Event event;
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            window.close();
    }
}

void Game::update() {
    world->update(); // Update the world logic
}

void Game::render() {
    window.clear();
    displayentities(window);
    window.display();
}
void Game::displayentities(sf::RenderWindow& window) {
    for(std::shared_ptr<PlatformView> platform : platforms) {
        window.draw(platform->getSprite());
    }
    window.draw(player->getSprite());
}

void Game::addPlayerView(std::shared_ptr<PlayerView> v) {
    std::cout << "Adding player view" << v.get() << std::endl;
    player = v;
}
void Game::addPlatformView(std::shared_ptr<PlatformView> v) {
    platforms.push_back(v);
}
std::shared_ptr<PlayerView> Game::getPlayerView() {
    return player;  // Debugging method to retrieve the current player view
}