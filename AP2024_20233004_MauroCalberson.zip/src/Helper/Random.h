
#include <random>
#ifndef DOODLEJUMP_RANDOM_H
#define DOODLEJUMP_RANDOM_H
int generatenumber(double bound1, int bound2);
class Random {
};
struct BoundingBox {
    float leftbound;
    float rightbound;
    float topbound;
    float bottombound;
};

#endif // DOODLEJUMP_RANDOM_H
