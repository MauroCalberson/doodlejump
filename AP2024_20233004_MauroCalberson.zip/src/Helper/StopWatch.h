

#ifndef DOODLEJUMP_STOPWATCH_H
#define DOODLEJUMP_STOPWATCH_H

class StopWatch {};

#endif // DOODLEJUMP_STOPWATCH_H
